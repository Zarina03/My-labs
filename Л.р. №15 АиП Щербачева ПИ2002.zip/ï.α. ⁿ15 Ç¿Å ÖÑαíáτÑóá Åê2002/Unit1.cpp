// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner) {
}

AnsiString NumberToRome(unsigned number)
{

    const struct TNumber {
		AnsiString rome;
        unsigned number;
    }   CNumber[] = { {"I",    1}, {"IV",   4}, {"V",   5}, {"IX",   9},
                     {"X",   10}, {"XL",  40}, {"L",  50}, {"XC",  90},
                     {"�",  100}, {"CD", 400}, {"D", 500}, {"CM", 900},
                     {"M", 1000} };
	unsigned i = sizeof(CNumber) / sizeof(*CNumber) - 1;
	AnsiString rome;

    while(number)
    {

        for(; CNumber[i].number > number; --i) { ; }

        rome += CNumber[i].rome;
		number -= CNumber[i].number;
    }

    return rome;
}
// ---------------------------------------------------------------------------
void __fastcall TForm1::ComboBox1KeyPress(TObject *Sender, wchar_t &Key) {
	if (Key == 13) { // ���� ������ ������� Enter, ��...
		// ������ �� ���� ��������������
		ListBox1->Items->Add(ComboBox1->Text);
		ComboBox1->Items->Add(ComboBox1->Text);
		ComboBox1->Text = ""; // ������� ���� ��������������
	}
}

void __fastcall TForm1::ListBox1Click(TObject *Sender)
{
	int n = 0; // �������� ����� ����
	int ind = 0;
	int nst = ListBox1->ItemIndex;
	AnsiString st = ListBox1->Items->Strings[nst];

	Label2->Caption = NumberToRome(StrToInt(st));
}
//---------------------------------------------------------------------------

